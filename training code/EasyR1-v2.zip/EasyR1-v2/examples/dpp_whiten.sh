#!/bin/bash

set -x

export PYTHONUNBUFFERED=1
# export CUDA_VISIBLE_DEVICES=0,1,2,3
export CUDA_VISIBLE_DEVICES=5,7
export RAY_allowed_local_fs_capacity_threshold=0.99
export RAY_local_fs_capacity_threshold=1
export TRANSFORMERS_OFFLINE=1
export HF_DATASETS_OFFLINE=1
export HF_HUB_OFFLINE=1
# export RAY_USAGE_STATS_ENABLED=0
# export RAY_DISABLE_USAGE_STATS=1
# export RAY_SCHEDULER_EVENTS=0
# MODEL_PATH="/data01/sdz/models/Qwen3-1.7B/snapshots/0060bc56d46589041c1048efd1a397421b1142b5"
# MODEL_PATH=Qwen/Qwen3-8B
# MODEL_PATH=/hpc/home/kai_he/.cache/huggingface/hub/models--Qwen--Qwen3-8B/snapshots/b968826d9c46dd6066d109eabc6255188de91218
# MODEL_PATH=deepseek-ai/DeepSeek-R1-0528-Qwen3-8B
# MODEL_PATH=/data01/sdz/models/Qwen3-8B
# MODEL_PATH=HeAAAAA/story_generation_Qwen3_8B_SFT

# MODEL_PATH=HeAAAAA/story_generation_Qwen3_8B_SFT
# python -m verl.trainer.main \
#     config=examples/qw_sft_dpp_whiten.yaml \
#     worker.actor.model.model_path=${MODEL_PATH}

MODEL_PATH=meta-llama/Llama-3.1-8B-Instruct
python -m verl.trainer.main \
    config=examples/llama_dpp_whiten.yaml \
    worker.actor.model.model_path=${MODEL_PATH}