# Copyright 2024 Bytedance Ltd. and/or its affiliates
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import math
import os
from collections import defaultdict
from io import BytesIO
from typing import Any, Optional, Union
import copy
import numpy as np
import torch
from datasets import load_dataset
from jinja2 import Template
from PIL import Image
from PIL.Image import Image as ImageObject
from qwen_vl_utils.vision_process import fetch_video
from torch.utils.data import Dataset
from transformers import PreTrainedTokenizer, ProcessorMixin
import random
from . import torch_functional as VF


def collate_fn(features: list[dict[str, Any]]) -> dict[str, Any]:
    tensors = defaultdict(list)
    non_tensors = defaultdict(list)
    for feature in features:
        for key, value in feature.items():
            if isinstance(value, torch.Tensor):
                tensors[key].append(value)
            else:
                non_tensors[key].append(value)

    for key, value in tensors.items():
        tensors[key] = torch.stack(value, dim=0)

    for key, value in non_tensors.items():
        non_tensors[key] = np.array(value, dtype=object)

    return {**tensors, **non_tensors}


def process_image(
    image: Union[dict[str, Any], ImageObject, str],
    min_pixels: Optional[int],
    max_pixels: Optional[int],
) -> ImageObject:
    if isinstance(image, str):
        image = Image.open(image)
    elif isinstance(image, dict):
        image = Image.open(BytesIO(image["bytes"]))
    elif isinstance(image, bytes):
        image = Image.open(BytesIO(image))

    image.load()  # avoid "Too many open files" errors
    if max_pixels is not None and (image.width * image.height) > max_pixels:
        resize_factor = math.sqrt(max_pixels / (image.width * image.height))
        width, height = int(image.width * resize_factor), int(
            image.height * resize_factor
        )
        image = image.resize((width, height))

    if min_pixels is not None and (image.width * image.height) < min_pixels:
        resize_factor = math.sqrt(min_pixels / (image.width * image.height))
        width, height = int(image.width * resize_factor), int(
            image.height * resize_factor
        )
        image = image.resize((width, height))

    if image.mode != "RGB":
        image = image.convert("RGB")

    return image


def process_video(
    video: str,
    min_pixels: Optional[int],
    max_pixels: Optional[int],
    video_fps: float,
    return_fps: bool = False,
) -> Union[list[ImageObject], tuple[list[ImageObject], list[float]]]:
    vision_info = {
        "video": video,
        "min_pixels": min_pixels,
        "max_pixels": max_pixels,
        "fps": video_fps,
    }
    return fetch_video(vision_info, return_video_sample_fps=return_fps)


class RLHFDataset(Dataset):
    """
    We assume the dataset contains a column that contains prompts and other information
    """

    def __init__(
        self,
        data_path: str,
        tokenizer: PreTrainedTokenizer,
        processor: Optional[ProcessorMixin],
        prompt_key: str = "prompt",
        answer_key: str = "answer",
        image_key: str = "images",
        video_key: str = "videos",
        image_dir: Optional[str] = None,
        video_fps: float = 2.0,
        max_prompt_length: int = 1024,
        truncation: str = "error",
        format_prompt: Optional[str] = None,
        min_pixels: Optional[int] = None,
        max_pixels: Optional[int] = None,
        filter_overlong_prompts: bool = True,
        filter_overlong_prompts_workers: int = 16,
        enable_diversity_prompt: bool =True, 
        diversity_prompt_prob: float=0.3
    ):
        self.tokenizer = tokenizer
        self.processor = processor
        self.prompt_key = prompt_key
        self.answer_key = answer_key
        self.image_key = image_key
        self.video_key = video_key
        self.image_dir = image_dir
        self.video_fps = video_fps
        self.max_prompt_length = max_prompt_length
        self.truncation = truncation
        self.min_pixels = min_pixels
        self.max_pixels = max_pixels

        if "@" in data_path:
            data_path, data_split = data_path.split("@")
        else:
            data_split = "train"

        if os.path.isdir(data_path):
            # when we use dataset builder, we should always refer to the train split
            file_type = os.path.splitext(os.listdir(data_path)[0])[-1][1:].replace(
                "jsonl", "json"
            )
            self.dataset = load_dataset(file_type, data_dir=data_path, split=data_split)
        elif os.path.isfile(data_path):
            file_type = os.path.splitext(data_path)[-1][1:].replace("jsonl", "json")
            self.dataset = load_dataset(
                file_type, data_files=data_path, split=data_split
            )
        else:
            # load remote dataset from huggingface hub
            self.dataset = load_dataset(data_path, split=data_split)

        self.format_prompt = None
        if format_prompt:
            with open(format_prompt, encoding="utf-8") as f:
                self.format_prompt = f.read()

        if filter_overlong_prompts:
            self.dataset = self.dataset.filter(
                self._filter_overlong_prompts,
                desc="Filtering overlong prompts",
                num_proc=filter_overlong_prompts_workers,
            )
        
        self.enable_diversity_prompt = enable_diversity_prompt
        self.diversity_prompt_prob = diversity_prompt_prob

        self.diversity_prompt_text_zh = (
            "\n\n[额外要求] 请让接下来剧情的发展更具多样性。"
            "可以从不同人物视角、事件推进方式、情绪变化、信息揭示顺序或环境互动等不同角度展开，"
            "避免与常见续写方式过于相似，但仍需保持剧情连贯、符合当前上下文，并遵守原有输出格式要求。"
        )

        self.diversity_prompt_text_en = (
            "\n\n[Additional Requirement] Please make the next part of the story more diverse. "
            "You may continue the plot from different perspectives, event progressions, emotional developments, "
            "information reveal orders, or environmental interactions. "
            "Avoid overly stereotypical continuations, while still keeping the story coherent with the current context "
            "and strictly following the required output format."
        )

    def _append_diversity_instruction(self, messages, instruction: str):
        """
        messages: list[dict], each dict like {"role": "...", "content": "..."}
        return: deep-copied modified messages
        """
        messages = copy.deepcopy(messages)

        # 优先加到最后一个 user message
        # for i in range(len(messages) - 1, -1, -1):
        #     if messages[i].get("role") == "user":
        #         messages[i]["content"] = messages[i]["content"] + instruction
        #         return messages

        # 如果没有 user，就退而求其次加到最后一个 system
        for i in range(len(messages) - 1, -1, -1):
            if messages[i].get("role") == "system":
                messages[i]["content"] = messages[i]["content"] + instruction
                return messages

        # 再不行就直接 append 一个 user
        messages.append({"role": "user", "content": instruction.strip()})
        return messages
    
    def _build_messages(self, example: dict[str, Any]) -> list[dict[str, Any]]:
        prompt_str: str = example[self.prompt_key]
        if self.format_prompt:
            format_prompt = Template(self.format_prompt.strip())
            prompt_str = format_prompt.render(content=prompt_str)

        if self.image_key in example:
            # https://huggingface.co/docs/transformers/en/tasks/image_text_to_text
            content_list = []
            for i, content in enumerate(prompt_str.split("<image>")):
                if i != 0:
                    content_list.append({"type": "image"})

                if content:
                    content_list.append({"type": "text", "text": content})

            return [{"role": "user", "content": content_list}]
        elif self.video_key in example:
            content_list = []
            for i, content in enumerate(prompt_str.split("<video>")):
                if i != 0:
                    content_list.append({"type": "video"})

                if content:
                    content_list.append({"type": "text", "text": content})

            return [{"role": "user", "content": content_list}]
        else:
            return [{"role": "user", "content": prompt_str}]

    def _filter_overlong_prompts(self, example: dict[str, Any]) -> bool:
        messages = self._build_messages(example)
        if self.image_key in example:
            prompt = self.processor.apply_chat_template(
                messages, add_generation_prompt=True, tokenize=False
            )
            images = example[self.image_key]
            if (
                self.image_dir is not None
                and len(images) != 0
                and isinstance(images[0], str)
            ):  # image paths
                images = [os.path.join(self.image_dir, image) for image in images]

            processed_images = [] if len(images) != 0 else None  # text-only data
            for image in images:
                processed_images.append(
                    process_image(image, self.min_pixels, self.max_pixels)
                )

            model_inputs = self.processor(
                processed_images,
                [prompt],
                add_special_tokens=False,
                return_tensors="pt",
            )
            return model_inputs["input_ids"].size(-1) <= self.max_prompt_length
        elif self.video_key in example:
            prompt = self.processor.apply_chat_template(
                messages, add_generation_prompt=True, tokenize=False
            )
            videos = example[self.video_key]
            if (
                self.image_dir is not None
                and len(videos) != 0
                and isinstance(videos[0], str)
            ):  # video paths
                videos = [os.path.join(self.image_dir, video) for video in videos]

            processed_videos = [] if len(videos) != 0 else None  # text-only data
            for video in videos:
                processed_videos.append(
                    process_video(
                        video, self.min_pixels, self.max_pixels, self.video_fps
                    )
                )

            model_inputs = self.processor(
                videos=processed_videos,
                text=[prompt],
                add_special_tokens=False,
                return_tensors="pt",
            )
            return model_inputs["input_ids"].size(-1) <= self.max_prompt_length
        else:
            input_ids = self.tokenizer.apply_chat_template(
                messages, add_generation_prompt=True
            )
            return len(input_ids) <= self.max_prompt_length

    def __len__(self):
        return len(self.dataset)

    # def __getitem__(self, index):
    #     # 额外写了一个函数，专门用来获得story_generation任务的数据
    #     if True:
    #         return self.__getStoryItem__(self, index)
    #     # ! 这里最好写个额外的判断进入
    #     example: dict = self.dataset[index]
    #     messages = self._build_messages(example)
    #     example.pop(self.prompt_key, None)

    #     if self.image_key in example:
    #         prompt = self.processor.apply_chat_template(
    #             messages, add_generation_prompt=True, tokenize=False
    #         )
    #         images = example.pop(self.image_key)
    #         if (
    #             self.image_dir is not None
    #             and len(images) != 0
    #             and isinstance(images[0], str)
    #         ):  # image paths
    #             images = [os.path.join(self.image_dir, image) for image in images]

    #         processed_images = [] if len(images) != 0 else None  # text-only data
    #         for image in images:
    #             processed_images.append(
    #                 process_image(image, self.min_pixels, self.max_pixels)
    #             )

    #         model_inputs = self.processor(
    #             processed_images,
    #             [prompt],
    #             add_special_tokens=False,
    #             return_tensors="pt",
    #         )
    #         input_ids = model_inputs.pop("input_ids")[0]
    #         attention_mask = model_inputs.pop("attention_mask")[0]
    #         example["multi_modal_data"] = {"images": images}
    #     elif self.video_key in example:
    #         prompt = self.processor.apply_chat_template(
    #             messages, add_generation_prompt=True, tokenize=False
    #         )
    #         videos = example.pop(self.video_key)
    #         if (
    #             self.image_dir is not None
    #             and len(videos) != 0
    #             and isinstance(videos[0], str)
    #         ):  # video paths
    #             videos = [os.path.join(self.image_dir, video) for video in videos]

    #         processed_videos = [] if len(videos) != 0 else None  # text-only data
    #         video_fps_list = []
    #         for video in videos:
    #             processed_video, video_fps = process_video(
    #                 video,
    #                 self.min_pixels,
    #                 self.max_pixels,
    #                 self.video_fps,
    #                 return_fps=True,
    #             )
    #             processed_videos.append(processed_video)
    #             video_fps_list.append(video_fps)

    #         model_inputs = self.processor(
    #             videos=processed_videos,
    #             text=[prompt],
    #             add_special_tokens=False,
    #             return_tensors="pt",
    #         )
    #         if "second_per_grid_ts" in self.processor.model_input_names:
    #             model_inputs["second_per_grid_ts"] = [
    #                 2.0 / video_sample_fps for video_sample_fps in video_fps_list
    #             ]

    #         input_ids = model_inputs.pop("input_ids")[0]
    #         attention_mask = model_inputs.pop("attention_mask")[0]
    #         example["multi_modal_data"] = {"videos": videos}
    #     else:
    #         prompt = self.tokenizer.apply_chat_template(
    #             messages, add_generation_prompt=True, tokenize=False
    #         )
    #         model_inputs = self.tokenizer(
    #             [prompt], add_special_tokens=False, return_tensors="pt"
    #         )
    #         input_ids = model_inputs.pop("input_ids")[0]
    #         attention_mask = model_inputs.pop("attention_mask")[0]

    #     if (
    #         self.processor is not None
    #         and "Qwen2VLImageProcessor"
    #         in self.processor.image_processor.__class__.__name__
    #     ):
    #         # qwen-vl mrope
    #         if "Qwen3VLProcessor" in self.processor.__class__.__name__:
    #             from ..models.transformers.qwen3_vl import get_rope_index
    #         else:
    #             from ..models.transformers.qwen2_vl import get_rope_index

    #         vision_position_ids = get_rope_index(
    #             self.processor,
    #             input_ids=input_ids,
    #             image_grid_thw=model_inputs.get("image_grid_thw", None),
    #             video_grid_thw=model_inputs.get("video_grid_thw", None),
    #             second_per_grid_ts=model_inputs.get("second_per_grid_ts", None),
    #             attention_mask=attention_mask,
    #         )  # (3, seq_length)
    #         text_position_ids = torch.arange(len(input_ids)).unsqueeze(
    #             0
    #         )  # (1, seq_length)
    #         position_ids = torch.cat(
    #             (text_position_ids, vision_position_ids), dim=0
    #         )  # (4, seq_length)
    #     else:
    #         position_ids = torch.clip(
    #             attention_mask.cumsum(dim=0) - 1, min=0, max=None
    #         )  # (seq_length,)

    #     input_ids, attention_mask, position_ids = VF.postprocess_data(
    #         input_ids=input_ids,
    #         attention_mask=attention_mask,
    #         position_ids=position_ids,
    #         max_length=self.max_prompt_length,
    #         pad_token_id=self.tokenizer.pad_token_id,
    #         left_pad=True,
    #         truncation=self.truncation,
    #     )
    #     raw_prompt_ids = self.tokenizer.encode(prompt, add_special_tokens=False)
    #     if len(raw_prompt_ids) > self.max_prompt_length:
    #         if self.truncation == "left":
    #             raw_prompt_ids = raw_prompt_ids[-self.max_prompt_length :]
    #         elif self.truncation == "right":
    #             raw_prompt_ids = raw_prompt_ids[: self.max_prompt_length]
    #         elif self.truncation == "error":
    #             raise RuntimeError(
    #                 f"Prompt length {len(raw_prompt_ids)} is longer than {self.max_prompt_length}."
    #             )

    #     example["input_ids"] = input_ids
    #     example["attention_mask"] = attention_mask
    #     example["position_ids"] = position_ids
    #     example["raw_prompt_ids"] = raw_prompt_ids
    #     example["ground_truth"] = example.pop(self.answer_key)
    #     return example

    def __getitem__(self, index):
        '''
        example: dict = self.dataset[index]

        # list[str]
        prompt_with_r = example["prompt"]
        user_input = example["user_input"]
        system_prompt = example["system_prompt"]
        # language = example['language']
        # if language == 'chinese':
        #     new_prompt = "请只输出最终答案，不要包含任何思考过程、推理步骤或中间计算。不要输出thinking过程。"
        # else:
        #     new_prompt = "Please only output the final answer, without including any thought process, reasoning steps, or intermediate calculations. Do not output the thinking process."
        # prompt_with_r[0]['content'] = prompt_with_r[0]['content'] + new_prompt
        # system_prompt[0]['content'] = system_prompt[0]['content'] + new_prompt
        # example.pop(self.prompt_key, None)
        # print(f"p with r: {prompt_with_r}")
        # print(f"user input: {user_input}")
        # print(f"system prompt: {system_prompt}")
        # 经过检验，这几个已经是list格式了，也符合content, role的格式
        # list[str]
        prompt_without_r = system_prompt + user_input
        # print(f"Tokenizer type: {type(self.tokenizer)}")
        # print(f"Current Chat Template: {self.tokenizer.chat_template}")
        '''
        


        example: dict = copy.deepcopy(self.dataset[index])

        prompt_with_r = copy.deepcopy(example["prompt"])
        user_input = copy.deepcopy(example["user_input"])
        system_prompt = copy.deepcopy(example["system_prompt"])

        prompt_without_r = system_prompt + user_input


        # ===== 随机决定是否加入 diversity prompt =====
        use_diversity_prompt = False
        if self.enable_diversity_prompt:
            use_diversity_prompt = (random.random() < self.diversity_prompt_prob)

        # 你如果有 language 字段，可以按语言选提示词；没有就默认中文
        language = example.get("language", "chinese")
        diversity_instruction = (
            self.diversity_prompt_text_zh
            if language == "chinese"
            else self.diversity_prompt_text_en
        )

        if use_diversity_prompt:
            prompt_with_r = self._append_diversity_instruction(
                prompt_with_r, diversity_instruction
            )
            prompt_without_r = self._append_diversity_instruction(
                prompt_without_r, diversity_instruction
            )

        # 记录这个 sample 是否加了 diversity prompt，方便后续 debug / reward 分析
        example["use_diversity_prompt"] = use_diversity_prompt
        prompt_with_r = self.tokenizer.apply_chat_template(
            prompt_with_r, add_generation_prompt=True, tokenize=False
        )
        prompt_without_r = self.tokenizer.apply_chat_template(
            prompt_without_r, add_generation_prompt=True, tokenize=False
        )
        # print(f"type p with r: {type(prompt_with_r)}")
        # print(f"p with r after template: {prompt_with_r}")
        # print(f"p wo r after template: {prompt_without_r}")

        """prompt_with_r: model_inputs"""
        model_inputs = self.tokenizer(
            [prompt_with_r], add_special_tokens=False, return_tensors="pt"
        )
        input_ids = model_inputs.pop("input_ids")[0]
        attention_mask = model_inputs.pop("attention_mask")[0]
        position_ids = torch.clip(
            attention_mask.cumsum(dim=0) - 1, min=0, max=None
        )  # (seq_length,)

        input_ids, attention_mask, position_ids = VF.postprocess_data(
            input_ids=input_ids,
            attention_mask=attention_mask,
            position_ids=position_ids,
            max_length=self.max_prompt_length,
            pad_token_id=self.tokenizer.pad_token_id,
            left_pad=True,
            truncation=self.truncation,
        )
        raw_prompt_ids = self.tokenizer.encode(prompt_with_r, add_special_tokens=False)
        if len(raw_prompt_ids) > self.max_prompt_length:
            if self.truncation == "left":
                raw_prompt_ids = raw_prompt_ids[-self.max_prompt_length :]
            elif self.truncation == "right":
                raw_prompt_ids = raw_prompt_ids[: self.max_prompt_length]
            elif self.truncation == "error":
                raise RuntimeError(
                    f"Prompt length {len(raw_prompt_ids)} is longer than {self.max_prompt_length}."
                )

        example["input_ids"] = input_ids
        example["attention_mask"] = attention_mask
        example["position_ids"] = position_ids
        example["raw_prompt_ids"] = raw_prompt_ids
        example["ground_truth"] = example.pop(self.answer_key)

        """prompt_without_r: model_inputs_without_r"""
        model_inputs_without_r = self.tokenizer(
            [prompt_without_r], add_special_tokens=False, return_tensors="pt"
        )
        input_ids_without_r = model_inputs_without_r.pop("input_ids")[0]
        attention_mask_without_r = model_inputs_without_r.pop("attention_mask")[0]
        position_ids_without_r = torch.clip(
            attention_mask_without_r.cumsum(dim=0) - 1, min=0, max=None
        )  # (seq_length,)

        input_ids_without_r, attention_mask_without_r, position_ids_without_r = (
            VF.postprocess_data(
                input_ids=input_ids_without_r,
                attention_mask=attention_mask_without_r,
                position_ids=position_ids_without_r,
                max_length=self.max_prompt_length,
                pad_token_id=self.tokenizer.pad_token_id,
                left_pad=True,
                truncation=self.truncation,
            )
        )
        raw_prompt_ids_without_r = self.tokenizer.encode(
            prompt_without_r, add_special_tokens=False
        )
        if len(raw_prompt_ids_without_r) > self.max_prompt_length:
            if self.truncation == "left":
                raw_prompt_ids_without_r = raw_prompt_ids_without_r[
                    -self.max_prompt_length :
                ]
            elif self.truncation == "right":
                raw_prompt_ids_without_r = raw_prompt_ids_without_r[
                    : self.max_prompt_length
                ]
            elif self.truncation == "error":
                raise RuntimeError(
                    f"Prompt length {len(raw_prompt_ids_without_r)} is longer than {self.max_prompt_length}."
                )

        example["input_ids_without_r"] = input_ids_without_r
        example["attention_mask_without_r"] = attention_mask_without_r
        example["position_ids_without_r"] = position_ids_without_r
        example["raw_prompt_ids_without_r"] = raw_prompt_ids_without_r

        return example