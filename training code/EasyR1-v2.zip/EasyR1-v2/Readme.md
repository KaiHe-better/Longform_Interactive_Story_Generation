# Brief notes on the project structure

Based on verl + vLLM + LoRA


## Dataset

The original datasets provided are all in JSON format. However, verl requires Parquet format. In practice, they are quite similar.

Suppose the original JSON is:

```json
{
  "system": "You are a story-generation AI...",
  "conversations": [
    {"from": "user", "value": "User action 1"},
    {"from": "assistant", "value": "Assistant response 1"},
    {"from": "user", "value": "User action 2"}, 
    {"from": "assistant", "value": "Assistant response 2"},
    {"from": "user", "value": "User action 3"},
    {"from": "assistant", "value": "Assistant response 3"},
    {"from": "user", "value": "User action 4"},
    {"from": "assistant", "value": "Assistant response 4"}
  ]
}
```

The script converts it into four independent training samples. The converted Parquet format is roughly like this:

```json
{
  "prompt": [
    {"role": "system", "content": "You are a story-generation AI..."},
    {"role": "user", "content": "User action 1"}
  ],
  "target_response": "Assistant response 1"
}

{
  "prompt": [
    {"role": "system", "content": "You are a story-generation AI..."},
    {"role": "user", "content": "User action 1"},
    {"role": "assistant", "content": "Assistant response 1"},
    {"role": "user", "content": "User action 2"}
  ],
  "target_response": "Assistant response 2"
}

{
  "prompt": [
    {"role": "system", "content": "You are a story-generation AI..."},
    {"role": "user", "content": "User action 1"},
    {"role": "assistant", "content": "Assistant response 1"},
    {"role": "user", "content": "User action 2"},
    {"role": "assistant", "content": "Assistant response 2"},
    {"role": "user", "content": "User action 3"}
  ],
  "target_response": "Assistant response 3"
}

{
  "prompt": [
    {"role": "system", "content": "You are a story-generation AI..."},
    {"role": "user", "content": "User action 1"},
    {"role": "assistant", "content": "Assistant response 1"},
    {"role": "user", "content": "User action 2"},
    {"role": "assistant", "content": "Assistant response 2"},
    {"role": "user", "content": "User action 3"},
    {"role": "assistant", "content": "Assistant response 3"},
    {"role": "user", "content": "User action 4"}
  ],
  "target_response": "Assistant response 4"
}
```

One issue suddenly came to mind. **We set `target_response` as the reference answer for the final response. However, our reward function does not include this part.**  
If we calculate scores based on our designed reward function, then the information the model learns should not be limited to the context alone. It should not simply learn how to match the reference answer, but should aim to produce responses that are better than the reference answer.

The dataset contains these fields. You can directly print the structure of one data sample using:

`python EasyR1/scripts/print_parquet.py`

>(Pdb) first_train_data.keys()
dict_keys(['data_source', 'prompt', 'ability', 'reward_model', 'target_response', 'extra_info', 'system_prompt', 'conversation_history', 'story_content', 'user_input', 'output_format'])


```python
system_prompt = instruction + story_content + output_format
prompt = system_prompt + conversation_history + user_input
```

## How to feed the dataset into training

The main code is located here:

`EasyR1/verl/utils/dataset.py: Line406`

The `_getitem_` function has been rewritten.

## Reward function

This is the reward function code for multi-turn story generation.

```
/root/rl-llm/EasyR1/examples/reward_function/story_generation.py
```

The difference from `math.py`, which is used for mathematical reasoning, is that math tasks have a ground truth answer to judge whether the response is correct. In contrast, our reward function relies only on the intermediate states during model execution. Of course, this still needs further optimization.

Similarly, we also have a format reward for answer formatting.

TODO:  
The format reward has not yet been implemented.

A Jinja format file needs to be added:

```
/root/rl-llm/EasyR1/examples/format_prompt/story_generation.jinja
```

Of course, to implement this reward function, we need to obtain and save the intermediate results from model inference.

The rollout strategy, namely the output generation strategy, is written in:

`/root/rl-llm/EasyR1/verl/workers/rollout/vllm_rollout_spmd.py: Line173`

The key code is here. In the second version, this function was modified so that it only generates the `with_r` response once.

```python
class vLLMRollout(BaseRollout):
    # ...
    def generate_sequences_r(self, prompts: DataProto) -> DataProto:
    # ...
```

**Very, very important:**  
After testing, we found that returning all log probabilities during generation causes extremely large overhead.

Therefore, these logits need to be obtained during `compute_logprob`, specifically during `micro_batch_forward` in `dp_actor.py`. At the same time, entropy and information flow can also be computed directly there.

After that, these values can be passed directly into the reward function.

`compute_reward` also has a preceding function: `worker.reward.BatchFunctionRewardManager.compute_reward`. This part has also been modified for our task.

## How to run?

The relevant experimental variables are all written in this YAML file:

```
/root/rl-llm/EasyR1/examples/story_config.yaml
```

This configuration file is very important. In addition, the rollout strategy config is located at:

`/root/rl-llm/EasyR1/verl/workers/rollout/config.py`

```sh
bash examples/qwen3_1.7b_story_grpo.sh
```

## Code framework

The `verl` folder contains the main classes.

The training procedure is in:

`verl/trainer/ray_trainer.py`

Specifically, see `Class RayPPOTrainer.fit`.

## Running pipeline

1. The data has already been processed into `with_r` and `without_r` prompts.
2. They are fed in together to form a batch and generate outputs jointly.
3. The logits are extracted from the generated results.
4. In `compute_score`, the embedding model is used to obtain embeddings.
5. The logits and embeddings are then combined to produce the final total reward.


## Notes

In `EasyR1/examples/story_config.yaml`, I have temporarily set all batch sizes to 1.

I also disabled KL divergence.

> If a runtime error occurs, it may be necessary to modify the maximum returned logprob value inside a Python package. But I forgot which package it was...  
> That was for the previous version. It is no longer needed now.